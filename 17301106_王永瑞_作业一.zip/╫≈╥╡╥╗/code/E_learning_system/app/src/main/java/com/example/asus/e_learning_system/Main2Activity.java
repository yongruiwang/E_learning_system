package com.example.asus.e_learning_system;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    private SearchView mSearchView;
    private ListView lListView;
    private String[] mStrs = {"操作系统", "移动应用开发技术", "数据库系统",
            "用户界面设计与评价","Web前端开发技术"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);



        mSearchView = (SearchView) findViewById(R.id.searchView);
        lListView = (ListView) findViewById(R.id.listView);
        lListView.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, mStrs));
        lListView.setTextFilterEnabled(true);
                // 设置搜索文本监听
        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            // 当点击搜索按钮时触发该方法
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            // 当搜索内容改变时触发该方法
            @Override
            public boolean onQueryTextChange(String newText) {
                if (!TextUtils.isEmpty(newText)){
                    lListView.setFilterText(newText);
                }else{
                    lListView.clearTextFilter();
                }
                return false;
            }
        });

        ArrayAdapter<String > mAdapter;
        mAdapter=new  ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,mStrs);
        lListView.setAdapter(mAdapter);
        lListView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
           //
                //
                //   parent.getSelectedView().toString();
                Intent i = new Intent(Main2Activity.this , Main3Activity.class);
                i.putExtra("data",mStrs[position]+"");
                startActivity(i);
            }});
    }


}



