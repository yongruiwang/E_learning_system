package com.example.asus.e_learning_system;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {
    private TextView tText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);


        tText=(TextView)findViewById(R.id.text);
        Intent i=getIntent();
        tText.setText(i.getStringExtra("data")+"\n课程信息\n教学大纲\n注册\n日历");


    }
}
